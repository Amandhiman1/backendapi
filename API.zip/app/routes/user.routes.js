
// routes/user.routes.js

module.exports = app => {
    const users = require("../controllers/user.controller");
    const { authenticateToken, authorizePermissions } = require("../middleware/auth");
    const { upload } = require("../middleware/upload_file");

    let router = require("express").Router();

    // Update user profile
    router.put("/profile", authenticateToken, upload.single('file'),  users.updateProfile);
    router.post('/', authenticateToken, authorizePermissions(['Admin', 'Manager', 'TeamLead']), users.createUser);
    router.get('/list', authenticateToken, users.getUserList);

    app.use("/api/users", router);
};
