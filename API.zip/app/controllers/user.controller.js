
const User = require('../models/user.model'); 
const bcrypt = require('bcrypt');

// Update user profile
exports.updateProfile = async (req, res) => {
    try {
        const userId = req.user.id; // Assuming req.user is set by the middleware
        const updates = req.body; // Get updates from the request body

        // Find the user and update the profile
        const user = await User.findByIdAndUpdate(userId, updates, { new: true });

        if (!user) {
            console.error({message: 'Update profile error: User not found'});
            return res.status(404).send({message: 'User not found'});
        }

        res.json(user);
    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).send({message: error.message || 'Some error occurred while updating the user '});
    }
};


exports.createUser = async (req, res) => {
    try {
        const { name, email, mobile, designation, role, empId, userType, languagePermissions, report_to } = req.body;
        const firstName = name?.split(' ')[0]
        const password = firstName.charAt(0).toUpperCase() + firstName.slice(1).toLowerCase() + '@123'

        if (req.user.role === 'Admin' && role === 'Admin') {
            return res.status(403).send({message: 'Admin users cannot create other Admin users'});
        }

        if (req.user.role === 'Manager' && role !== 'TeamLead' && role !== 'Executive') {
            return res.status(403).send({message:'Managers can only create TeamLead or Executives'});
        }
        if (req.user.role === 'TeamLead' && role !== 'Executive') {
            return res.status(403).send({message:'TeamLead can only create Executives'});
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const dbuser = await User.findOne({ email });
        if (dbuser) return res.status(409).send({message:'User already exist'});

        const user = new User({ name, email, password: hashedPassword, mobile, designation, role, empId, userType, languagePermissions });
        user.createdBy = req.user._id;
        user.report_to = report_to ? report_to : req.user._id;

        const userRes = await user.save();
        res.status(201).send({message:'User created successfully', data: userRes});
    } catch (err) {
        console.error('User creation error:', err);
        res.status(400).send({message: err.message || 'Some error occurred while creating the user '});
    }
};

exports.getUserList = async (req, res) => {
    try {
        let users;

        if (req.user.role === 'Admin') {
            // Admin can see all users
            users = await User.find().select('-password -isTwoFactorEnabled -refreshToken -twoFactorSecret');
        } else if (req.user.role === 'Manager') {
            // Manager can see their team's users (Team Leads and Executives created by them)
            users = await User.find({ report_to: req.user._id }).select('-password -isTwoFactorEnabled -refreshToken -twoFactorSecret');
        } else if (req.user.role === 'TeamLead') {
            // TeamLead can see their team's users (Executives created by them)
            users = await User.find({ report_to: req.user._id }).select('-password -isTwoFactorEnabled -refreshToken -twoFactorSecret');
        } else if (req.user.role === 'Executive') {
            // Executives cannot see the user list
            return res.status(403).send({ message: 'You do not have the required permissions to perform this action' });
        } else {
            return res.status(403).send({ message: 'You do not have the required permissions to perform this action' });
        }

        res.status(200).send(users);
    } catch (err) {
        console.error('Get user list error:', err);
        res.status(400).send({ message: err.message });
    }
};